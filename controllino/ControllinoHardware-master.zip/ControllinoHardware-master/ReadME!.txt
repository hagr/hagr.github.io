Controllino Hardware package for Arduino IDE 1.6.6
Version 1.2

Contains frozen arduino core, several arduino libraries and pin definiton files.

This package is common for all Controllino basic variants eg. MINI, MAXI, MEGA.
Content of this package belong into C:\Users\<User Name>\Documents\Arduino