This isa support library v01.00 for the Controllino MINI/MAXI/MEGA device

It contains all Controllino specific extensions to standard Arduino framework:
	- RTC API interface
	- RS485 interface
	- Examples how to use Controllino specific features

version history:
(18.1.206) - 01.00 - Tomas S - Fixed problem with compilation of Examples->Controllino_Example.
			 00.09 - Tomas S - RTC patch, added RTC example, corrected typo
			 00.08 - Tomas S - Updated for Controllino MAXI, added example
			 00.07 - Lukas S - Fixes for RS485
			 00.06 - Tomas S - Added support for new RTC.
			 00.05 - Tomas S - RS485 interface
			 00.04 - Tomas S - Updated for new maxi MCU
			 00.03 - Tomas S - Refurbished RTC library part
			 00.02 - Tomas S - Updated controllino.h
			 00.01 - Tomas S - added support for RTC chip, added new keywords.